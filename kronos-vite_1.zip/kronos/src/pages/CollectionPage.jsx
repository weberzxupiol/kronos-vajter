import { useState } from "react";
import { useScrollAnimationGroup } from "../hooks/useScrollAnimation";
import Navigation from "../components/Navigation";
import Footer from "../components/Footer";

const pieces = [
  {
    ref: "K-001",
    name: "Infinitum",
    series: "Quantum Series I",
    price: "$48,000",
    edition: "99 pieces",
    color: "Void Black",
    accent: "gold",
    desc: "The inaugural reference. Hand-assembled over 340 hours by a single master watchmaker.",
  },
  {
    ref: "K-002",
    name: "Tempus",
    series: "Quantum Series I",
    price: "$52,000",
    edition: "49 pieces",
    color: "Liquid Mercury",
    accent: "quantum",
    desc: "Brushed meteorite dial inlay, sourced from the Gibeon meteorite field. Unique by nature.",
  },
  {
    ref: "K-003",
    name: "Aevum",
    series: "Bespoke Atelier",
    price: "On Request",
    edition: "1 piece",
    color: "Bespoke",
    accent: "gold",
    desc: "A singular collaboration between client and master watchmaker. No two alike.",
  },
];

export default function CollectionPage() {
  const [hovered, setHovered] = useState(null);
  const ref = useScrollAnimationGroup();

  return (
    <div className="bg-kronos-black min-h-screen">
      <Navigation />

      {/* Header */}
      <section className="pt-40 pb-20 px-6 lg:px-12 max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <div className="quantum-dot" />
          <span className="section-label">2025 Collection</span>
        </div>
        <h1 className="font-display font-light text-[clamp(3rem,7vw,7rem)] leading-none tracking-tight">
          <span className="block text-white/90">Choose your</span>
          <span className="block text-gold-gradient italic">dimension</span>
        </h1>
      </section>

      <div className="px-6 lg:px-12 max-w-7xl mx-auto">
        <div className="divider-gold mb-16" />
      </div>

      {/* Collection list */}
      <section ref={ref} className="px-6 lg:px-12 max-w-7xl mx-auto pb-32">
        <div className="flex flex-col gap-0">
          {pieces.map((piece, i) => (
            <div
              key={piece.ref}
              className={`anim-ready group border-b border-white/5 py-10 grid lg:grid-cols-12 gap-6 cursor-pointer transition-all duration-500 ${
                hovered === i ? "bg-white/[0.02]" : ""
              }`}
              style={{ transitionDelay: `${i * 0.1}s` }}
              onMouseEnter={() => setHovered(i)}
              onMouseLeave={() => setHovered(null)}
            >
              {/* Ref */}
              <div className="lg:col-span-1 flex items-center">
                <span className="font-mono text-[11px] text-white/20 tracking-widest">{piece.ref}</span>
              </div>

              {/* Name */}
              <div className="lg:col-span-3 flex flex-col justify-center">
                <div className="section-label text-white/30 mb-1">{piece.series}</div>
                <h3 className={`font-display text-4xl lg:text-5xl font-light transition-all duration-500 ${
                  hovered === i
                    ? piece.accent === "quantum" ? "text-quantum-gradient" : "text-gold-gradient"
                    : "text-white/80"
                }`}>
                  {piece.name}
                </h3>
              </div>

              {/* Desc */}
              <div className="lg:col-span-4 flex items-center">
                <p className="text-sm text-white/35 leading-relaxed font-sans max-w-sm">{piece.desc}</p>
              </div>

              {/* Details */}
              <div className="lg:col-span-2 flex flex-col justify-center gap-2">
                <div>
                  <div className="section-label text-white/20 mb-0.5">Edition</div>
                  <div className="font-sans text-sm text-white/50">{piece.edition}</div>
                </div>
                <div>
                  <div className="section-label text-white/20 mb-0.5">Colour</div>
                  <div className="font-sans text-sm text-white/50">{piece.color}</div>
                </div>
              </div>

              {/* Price + CTA */}
              <div className="lg:col-span-2 flex flex-col items-start lg:items-end justify-center gap-3">
                <div className={`font-display text-2xl font-light ${piece.accent === "quantum" ? "text-kronos-quantum" : "text-kronos-gold"}`}>
                  {piece.price}
                </div>
                <button className="btn-primary py-2 px-4 text-[10px] opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  Reserve
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Reserve CTA */}
        <div className="mt-20 text-center">
          <p className="section-label text-white/25 mb-6">Availability is strictly limited. Reserve your consultation.</p>
          <a
            href="mailto:atelier@kronos.com"
            className="btn-primary inline-flex"
          >
            Contact the Atelier
          </a>
        </div>
      </section>

      <Footer />
    </div>
  );
}
