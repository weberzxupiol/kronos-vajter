import { useScrollAnimationGroup } from "../hooks/useScrollAnimation";
import Navigation from "../components/Navigation";
import Footer from "../components/Footer";

const layers = [
  {
    number: "I",
    title: "Quantum Oscillator",
    subtitle: "The Heart",
    description:
      "Our QC-7 oscillator operates by exploiting quantum tunneling through a Josephson junction cooled to 15mK. The result is a resonance frequency stable to 10⁻¹³ — surpassing any mechanical or electronic oscillator ever installed in a wearable device.",
    metric: "9.2 GHz",
    metricLabel: "Resonance Frequency",
  },
  {
    number: "II",
    title: "Entanglement Sync",
    subtitle: "The Nervous System",
    description:
      "Each Kronos Infinitum maintains quantum entanglement with our Geneva reference clock. Any deviation is corrected instantaneously, regardless of distance — exploiting non-local correlations predicted by Bell's theorem.",
    metric: "0 ms",
    metricLabel: "Sync Latency",
  },
  {
    number: "III",
    title: "Nano-Tribology Shell",
    subtitle: "The Armor",
    description:
      "A proprietary DLC-over-sapphire matrix, applied by Physical Vapor Deposition at 700°C, forms a surface 92% harder than steel. The nano-porous underlayer absorbs kinetic shock — protecting the oscillator from impacts up to 5000 G.",
    metric: "92%",
    metricLabel: "Harder than Steel",
  },
];

export default function TechnologyPage() {
  const ref = useScrollAnimationGroup();

  return (
    <div className="bg-kronos-black min-h-screen">
      <Navigation />

      {/* Page hero */}
      <section className="pt-40 pb-20 px-6 lg:px-12 max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <div className="quantum-dot" />
          <span className="section-label">Quantum Engineering</span>
        </div>
        <h1 className="font-display font-light text-[clamp(3rem,7vw,7rem)] leading-none tracking-tight">
          <span className="block text-white/90">The science</span>
          <span className="block text-gold-gradient italic">of impossible</span>
          <span className="block text-white/20">accuracy</span>
        </h1>
        <p className="mt-8 max-w-xl text-sm text-white/40 leading-relaxed font-sans">
          Three proprietary technologies converge inside each Kronos timepiece. Together they 
          represent a decade of research across quantum physics, materials science, and 
          Swiss horological tradition.
        </p>
      </section>

      <div className="px-6 lg:px-12 max-w-7xl mx-auto">
        <div className="divider-gold" />
      </div>

      {/* Technology layers */}
      <section ref={ref} className="py-24 px-6 lg:px-12 max-w-7xl mx-auto flex flex-col gap-0">
        {layers.map((layer, i) => (
          <div
            key={layer.number}
            className={`anim-ready grid lg:grid-cols-12 gap-8 py-16 border-b border-white/5 ${i === 0 ? "border-t" : ""}`}
            style={{ transitionDelay: `${i * 0.15}s` }}
          >
            {/* Number */}
            <div className="lg:col-span-1 flex lg:block items-center gap-4">
              <span className="font-display text-5xl font-thin text-white/10">{layer.number}</span>
            </div>

            {/* Label */}
            <div className="lg:col-span-2 flex flex-col justify-center">
              <div className="section-label text-kronos-gold/50 mb-1">{layer.subtitle}</div>
              <h3 className="font-display text-2xl lg:text-3xl font-light text-white/80">{layer.title}</h3>
            </div>

            {/* Description */}
            <div className="lg:col-span-6 flex items-center">
              <p className="text-sm text-white/40 leading-relaxed font-sans max-w-xl">{layer.description}</p>
            </div>

            {/* Metric */}
            <div className="lg:col-span-3 flex flex-col justify-center items-start lg:items-end">
              <div className="font-mono text-4xl lg:text-5xl font-light text-quantum-gradient">{layer.metric}</div>
              <div className="section-label text-white/25 mt-1">{layer.metricLabel}</div>
            </div>
          </div>
        ))}
      </section>

      <Footer />
    </div>
  );
}
