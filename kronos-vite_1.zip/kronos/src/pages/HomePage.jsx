import Navigation from "../components/Navigation";
import HeroSection from "../components/HeroSection";
import FeaturesSection from "../components/FeaturesSection";
import ProductShowcase from "../components/ProductShowcase";
import Footer from "../components/Footer";

export default function HomePage() {
  return (
    <div className="bg-kronos-black min-h-screen">
      <Navigation />
      <HeroSection />
      <FeaturesSection />
      <ProductShowcase />

      {/* Marquee ribbon */}
      <div className="py-6 border-y border-white/5 overflow-hidden my-16">
        <div className="flex gap-16 animate-[marquee_20s_linear_infinite] whitespace-nowrap">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="flex items-center gap-16 flex-shrink-0">
              <span className="section-label text-white/15">Quantum Precision</span>
              <div className="quantum-dot" style={{ width: "4px", height: "4px" }} />
              <span className="section-label text-white/15">Swiss Engineered</span>
              <div className="quantum-dot" style={{ width: "4px", height: "4px" }} />
              <span className="section-label text-white/15">Limited to 99 Pieces</span>
              <div className="quantum-dot" style={{ width: "4px", height: "4px" }} />
              <span className="section-label text-white/15">Certified by BIPM</span>
              <div className="quantum-dot" style={{ width: "4px", height: "4px" }} />
            </div>
          ))}
        </div>
      </div>

      <Footer />

      <style>{`
        @keyframes marquee {
          0%   { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}
