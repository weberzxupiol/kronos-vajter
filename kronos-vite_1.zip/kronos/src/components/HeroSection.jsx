import { useEffect, useRef } from "react";
import { Link } from "react-router-dom";

export default function HeroSection() {
  const headingRef = useRef(null);

  useEffect(() => {
    // stagger letters on mount
    const el = headingRef.current;
    if (!el) return;
    el.style.opacity = "1";
  }, []);

  return (
    <section className="relative h-screen min-h-[700px] flex items-end overflow-hidden">

      {/* ── VIDEO BACKGROUND ── */}
      {/* REPLACE src WITH YOUR HIGGSFIELD ASSET #1 */}
      <video
        src="/videos/hero-quantum.mp4"
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover"
        aria-hidden="true"
      />

      {/* Fallback gradient when video isn't loaded */}
      <div className="absolute inset-0 video-placeholder" aria-hidden="true" />

      {/* Animated particles overlay */}
      <ParticleOverlay />

      {/* Dark gradient overlay */}
      <div
        className="absolute inset-0"
        style={{
          background: "linear-gradient(to bottom, rgba(8,8,8,0.25) 0%, rgba(8,8,8,0.5) 50%, rgba(8,8,8,1) 100%)"
        }}
        aria-hidden="true"
      />

      {/* Scan line effect */}
      <div
        className="absolute inset-0 pointer-events-none overflow-hidden"
        aria-hidden="true"
      >
        <div className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-kronos-quantum/30 to-transparent animate-scan-line" />
      </div>

      {/* ── CONTENT ── */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 lg:px-12 pb-20 lg:pb-28">

        {/* Top label */}
        <div className="flex items-center gap-3 mb-8 opacity-0 animate-fade-up" style={{ animationDelay: "0.3s", animationFillMode: "forwards" }}>
          <div className="quantum-dot" />
          <span className="section-label">Est. 2024 — Geneva, Switzerland</span>
        </div>

        {/* Main heading */}
        <div
          ref={headingRef}
          className="opacity-0 animate-fade-up"
          style={{ animationDelay: "0.5s", animationFillMode: "forwards" }}
        >
          <h1 className="font-display font-light leading-none tracking-tight">
            <span className="block text-[clamp(3.5rem,10vw,9rem)] text-white/95">
              Time
            </span>
            <span className="block text-[clamp(3.5rem,10vw,9rem)] text-gold-gradient">
              Transcends
            </span>
            <span className="block text-[clamp(3.5rem,10vw,9rem)] text-white/30 italic">
              Dimension
            </span>
          </h1>
        </div>

        {/* Sub copy */}
        <p
          className="mt-8 max-w-xl font-sans font-light text-white/50 text-base leading-relaxed opacity-0 animate-fade-up"
          style={{ animationDelay: "0.8s", animationFillMode: "forwards" }}
        >
          The world's first quantum-entangled timepiece. Engineered at the intersection 
          of horological mastery and quantum mechanics — accurate to one picosecond 
          across the observable universe.
        </p>

        {/* CTA row */}
        <div
          className="mt-12 flex flex-wrap items-center gap-6 opacity-0 animate-fade-up"
          style={{ animationDelay: "1s", animationFillMode: "forwards" }}
        >
          <Link to="/collection" className="btn-primary">
            <span>Discover the Collection</span>
            <svg width="14" height="10" viewBox="0 0 14 10" fill="none">
              <path d="M1 5h12M8 1l4 4-4 4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </Link>

          <button className="flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center group-hover:border-kronos-gold/40 transition-colors duration-300">
              <svg width="10" height="12" viewBox="0 0 10 12" fill="none">
                <path d="M1 1l8 5-8 5V1z" fill="currentColor" className="text-white/50 group-hover:text-kronos-gold transition-colors duration-300" />
              </svg>
            </div>
            <span className="section-label text-white/40 group-hover:text-kronos-gold/60 transition-colors duration-300">
              Watch Film
            </span>
          </button>
        </div>

        {/* Scroll indicator */}
        <div
          className="absolute bottom-8 right-12 hidden lg:flex flex-col items-center gap-2 opacity-0 animate-fade-up"
          style={{ animationDelay: "1.4s", animationFillMode: "forwards" }}
        >
          <span className="section-label text-white/30 [writing-mode:vertical-rl] tracking-widest">
            Scroll to discover
          </span>
          <div className="w-px h-16 bg-gradient-to-b from-kronos-gold/40 to-transparent" />
        </div>

      </div>
    </section>
  );
}

function ParticleOverlay() {
  const particles = Array.from({ length: 24 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 2 + 0.5,
    delay: Math.random() * 6,
    duration: Math.random() * 4 + 4,
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full bg-kronos-quantum/40 animate-float"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: `${p.size}px`,
            height: `${p.size}px`,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
            boxShadow: `0 0 ${p.size * 4}px rgba(0,212,255,0.5)`,
          }}
        />
      ))}
    </div>
  );
}
